// Insert at any position of a dobly linked list using function
#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    struct Node* next;
};

int size = 0;

Node* getNode(int data)
{

    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}
void insertPos(Node** current, int pos, int data)
{

    if (pos < 1 || pos > size + 1)
        cout << "Invalid position!" << endl;
    else {


        while (pos--) {

            if (pos == 0) {

                Node* temp = getNode(data);


                temp->next = *current;


                *current = temp;
            }
            else

              current = &(*current)->next;
        }
        size++;
    }
}


void printList(struct Node* head)
{
    while (head != NULL) {
        cout << " " << head->data;
        head = head->next;
    }
    cout << endl;
}
int main()
{
    Node* head = NULL;
    head = getNode(101);
    head->next = getNode(202);
    head->next->next = getNode(303);
    head->next->next->next = getNode(404);

    size = 4;

    cout << "Linked list before insertion: ";
    printList(head);

    int data = 505, pos = 3;
    insertPos(&head, pos, data);
    cout << "Linked list after insertion of 505 at position 3: ";
    printList(head);

    data = 606, pos = 1;
    insertPos(&head, pos, data);
    cout << "Linked list after insertion of 606 at position 1: ";
    printList(head);

    data = 808, pos = 7;
    insertPos(&head, pos, data);
    cout << "Linked list after insertion of 808 at position 7: ";
    printList(head);

    return 0;
}
